'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList, TouchableOpacity, TextInput} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ScrollView } from 'react-native-gesture-handler';

class cart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      couponcode:''
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View style={{flex: 0.2}}>
      <View style={{flexDirection:'row'}}>
     <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'cart'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'map-marker'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'currency-inr'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'clipboard-text'} />
      </View>
      </TouchableOpacity>
      </View>
      <View style={{flexDirection:'row'}}>
      <Text style={{marginLeft: 30,marginTop: 30,fontSize: 16,fontWeight:'500'}}>Total Price</Text>
      <Text style={{marginLeft: 150,marginTop: 30,fontSize: 16,fontWeight:'500'}}>₹ 110.00</Text>
      </View>
      </View>
      <View style={{borderColor:"#B8B7B6",borderWidth: 1,marginVertical: 20}}></View>
      <View style={{flexDirection:'row', marginTop: 10}}>
     <View style={{flex:0.22, marginVertical: 10, marginLeft: 20}}>
     <Image source={{uri: "https://ayurcentralonline.com/4110-large_default/orthoherb-oil-100ml.jpg"}} style={{width: 100, height: 120}}/>
     </View>
     <View style={{flex: 0.6,marginVertical: 10}}>
     <Text style={{fontSize: 16, marginTop: 20}}>Orthoherb Oil</Text>
     <Text style={{fontSize: 12}}>₹ 110.00</Text>
     </View>
     <View style={{flex: 0.2}}>
     <View style={{height: 120,width: 30, borderRadius: 20,borderColor:"black",borderWidth: 1, marginTop: 10,marginLeft: 20}}>
      <View style={{height: 20,width:20,borderRadius: 50,borderColor:"black",borderWidth: 1,alignSelf:'center',justifyContent:'center',marginTop: 10}}>
     <Text style={{alignSelf:'center',justifyContent:'center',fontSize: 18}}>+</Text>
     </View>
     <View style={{height: 20,width:20,borderRadius: 50,borderColor:"black",borderWidth: 1,alignSelf:'center',justifyContent:'center',marginTop: 60}}>
     <Text style={{alignSelf:'center',justifyContent:'center',fontSize: 18}}>-</Text>
     </View>
     </View>
     </View>
      </View>
      <View style={{borderColor:"#B8B7B6",borderWidth: 1,marginVertical: 20}}></View>
      <View style={{flex: 0.6}}>
      <Text style={{marginTop: 20,marginHorizontal: 30,fontWeight:'bold'}}>COUPON CODE :</Text>
      <View style={{flexDirection:'row'}}>
      <View style={{height: 50,width: '50%', borderRadius: 20,borderColor:"white",borderWidth: 1, marginTop: 10,marginLeft: 20,backgroundColor:"white"}}>
      <TextInput style={{alignSelf:'center',justifyContent:'center'}}
            onChangeText={(couponcode) => this.setState({ couponcode })}
            value={this.state.couponcode} />
      </View>
      <View style={{height: 50,width: '40%', borderRadius: 20,borderColor:"white",borderWidth: 1, marginTop: 10,marginLeft: 20,backgroundColor:"#64609A"}}>
      <TouchableOpacity>
        <Text style={{alignSelf:'center',justifyContent:'center',color:'white',marginTop: 10}}>APPLY</Text>
      </TouchableOpacity>
      </View>
      </View>
      </View>
      <View style={{flex: 0.2}}>
        <View style={{flexDirection:'row'}}>
      <View style={{height: 50,width: '40%', borderRadius: 20,borderColor:"white",borderWidth: 1, marginTop: 10,marginLeft: 20,backgroundColor:"#67E3F9"}}>
      <Text style={{alignSelf:'center',justifyContent:'center',color:'white',marginTop: 10}}>BACK</Text>
      </View>
      <View style={{height: 50,width: '40%', borderRadius: 20,borderColor:"white",borderWidth: 1, marginTop: 10,marginLeft: 40,backgroundColor:"#6FF99D"}}>
      <Text style={{alignSelf:'center',justifyContent:'center',color:'white',marginTop: 10}}>NEXT STEP</Text>
      </View>
      </View>
      </View>
      </View>
    );
  }
}
export default cart;