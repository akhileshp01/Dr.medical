'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';


class doctorprofile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
       <View style={{flex: 0.3,backgroundColor:"#489258", marginVertical: 20,marginHorizontal: 20, borderRadius: 30}}>
       <View style={{alignSelf:'center',justifyContent:'center',height: 90, width: 90,borderRadius: 50,borderWidth: 5,borderColor:"white",marginTop: 60}}>
       <Icon
        style={{justifyContent: 'center',alignSelf: 'center',color: 'red',fontSize: 50,}}
        name={'check'} />
        </View>
        <Text style={{justifyContent: 'center',alignSelf: 'center',color:"white",fontSize: 18,marginTop: 10,fontWeight:'bold'}}>You're all set !</Text>
       </View>
       <View style={{flex: 0.33,backgroundColor:"white",marginHorizontal: 20, borderRadius: 30}}>
      <Text style={{fontSize: 18,fontWeight:'bold',marginHorizontal: 10,marginVertical: 10}}>Appointment Confirmation</Text>
      <View style={{flexDirection:'row'}}>
      <View style={{flex: 0.4,marginLeft: 20}}>
       <Text style={{fontWeight:'100',fontSize: 16,marginTop: 20}}>Name</Text>
       <Text style={{fontWeight:'100',fontSize: 16,marginTop:20}}>Date</Text>
       <Text style={{fontWeight:'100',fontSize: 16,marginTop:20}}>Time</Text>
      </View>
      <View style={{flex: 0.6}}>
      <Image source={{uri: "https://cdn4.iconfinder.com/data/icons/web-ui-color/128/Account-512.png"}} style={{width: 100, height: 100,marginLeft: 80,marginTop: 10}}/>
      <Text style={{fontWeight:'100',fontSize: 16, marginLeft: 90,marginVertical: 10}}>Dr.Name</Text>
      <Text style={{fontWeight:'100',fontSize: 16, marginLeft: 90}}>Department</Text>
      </View>
      </View>
       </View>
       <View style={{flexDirection:'row',marginVertical: 10,marginHorizontal: 20}}>
       <View style={{height: 40,width: 180,backgroundColor:"white",borderRadius: 20}}>
       <Text style={{justifyContent: 'center',alignSelf: 'center',marginTop: 10}}>Cancel Appointment</Text>
       </View>
       <View style={{height: 50,width: 100,backgroundColor:"#489258",borderRadius: 20,marginLeft: 50}}>
       <Icon
        style={{justifyContent: 'center',alignSelf: 'center',fontSize: 30,marginTop:10}}
        name={'phone'} />
       </View>
       </View>
      </View>
    );
  }
}
export default doctorprofile;