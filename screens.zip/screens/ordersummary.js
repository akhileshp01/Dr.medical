'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';


class doctorprofile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View style={{flex: 0.1,backgroundColor:"#4BBABB"}}>
      <Icon
        style={{fontSize: 30,marginTop:20,color:"white",marginLeft: 10}}
        name={'arrow-left'} />
         <Text style={{alignSelf:'center',justifyContent:'center',color: "white", fontSize: 18,fontWeight:'bold',marginVertical: 25}}></Text>
       </View>
       <View style={{flex: 0.9,marginVertical: 60}}>
       <Text style={{marginHorizontal: 50}}>Order ID: #000005482</Text>
       <View style={{flexDirection:"row", marginHorizontal: 50}}>
        <View>
        <Text style={{marginVertical: 20, fontSize: 15}}>Ortho herb Oil</Text>
        <Text style={{fontWeight:'bold',fontSize: 15}}>Subtotal</Text>
        <Text style={{marginVertical: 20, fontSize: 15,fontWeight:'bold'}}>Shipping</Text>
        </View>
        <View>
        <Text style={{marginVertical: 20, fontSize: 15,marginLeft: 100}}>₹ 110.00</Text>
        <Text style={{fontWeight:'bold',fontSize: 15,marginLeft: 100}}>₹ 110.00</Text>
        <Text style={{fontWeight:'bold',fontSize: 15,marginLeft: 100,marginVertical:20}}>₹40.00</Text>
        </View>
       </View>
       <View style={{borderColor:"#B8B7B6",borderWidth: 1}}></View>
       <View style={{flexDirection:'row'}}>
        <Text style={{fontWeight:'bold',fontSize: 15,marginHorizontal:50,marginVertical: 20}}>Total</Text>
        <Text style={{fontWeight:'bold',fontSize: 15,marginLeft: 110,marginVertical: 20}}>₹ 110.00</Text>
       </View>
       <Text style={{fontWeight:'bold',fontSize: 15, color:"green",marginHorizontal: 50}}>Status : Pending</Text>
       </View>
      </View>
    );
  }
}
export default doctorprofile;