'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

class schedule extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View style={{flex: 0.1,backgroundColor:"#4BBABB"}}>
      <Icon
        style={{fontSize: 30,marginTop:20,color:"white",marginLeft: 10}}
        name={'arrow-left'} />
       </View> 
       <View style={{flex: 0.3,backgroundColor:"#4BBABB",borderBottomLeftRadius: 40,borderBottomRightRadius: 40}}>
       <View style={{alignSelf:'center',justifyContent:'center',height: 90, width: 90,borderRadius: 50,borderWidth: 5,borderColor:"white",marginTop: 20}}>
       <Icon
        style={{justifyContent: 'center',alignSelf: 'center',color: 'red',fontSize: 50,}}
        name={'check'} />
        </View>
        <Text style={{justifyContent: 'center',alignSelf: 'center',color:"white",fontSize: 18,marginTop: 10}}>Appointment Confirmation</Text>
        </View> 
        <View style={{flex: 0.6}}>
        <Text style={{justifyContent: 'center',alignSelf: 'center',fontSize: 18,fontWeight:'bold',marginTop: 40}}>Your Schedule</Text>
        <View style={{flexDirection:'row',marginTop: 20}}>
        <View style={{flex:0.5}}>
        <Text style={{justifyContent: 'center',alignSelf: 'center',marginVertical: 20}}>Date</Text>
        <Text style={{justifyContent: 'center',alignSelf: 'center'}}>02/05/2020</Text>
        </View>
        <View style={{borderColor:"#B8B7B6",borderWidth: 1,marginTop: 5}}></View>
        <View style={{flex:0.5}}>
        <Text style={{justifyContent: 'center',alignSelf: 'center',marginVertical: 20}}>Time</Text>
        <Text style={{justifyContent: 'center',alignSelf: 'center'}}>10.00am</Text>   
        </View>
        </View>
        <View style={{flexDirection:'row',marginVertical: 10,marginHorizontal: 20}}>
        <TouchableOpacity>
       <View style={{height: 50,width: 180,backgroundColor:"red",borderRadius: 20,marginTop: 50}}>
       <Text style={{justifyContent: 'center',alignSelf: 'center',marginTop: 10}}>Cancel Appointment</Text>
       </View>
       </TouchableOpacity>
       <TouchableOpacity>
       <View style={{height: 50,width: 100,backgroundColor:"#489258",borderRadius: 20,marginLeft: 50,marginTop: 50}}>
       <Icon
        style={{justifyContent: 'center',alignSelf: 'center',fontSize: 30,marginTop:10}}
        name={'phone'} />
       </View>
       </TouchableOpacity>
       </View>
        </View>
      </View>
    );
  }
}
export default schedule;