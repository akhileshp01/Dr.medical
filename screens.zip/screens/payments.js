'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList, TouchableOpacity, TextInput} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ScrollView } from 'react-native-gesture-handler';

class payments extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      couponcode:''
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View style={{flex: 0.15}}>
      <View style={{flexDirection:'row'}}>
     <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'cart'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'map-marker'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'currency-inr'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'clipboard-text'} />
      </View>
      </TouchableOpacity>
      </View>
      </View>
      <View style={{flex: 0.7}}>
      <Text style={{marginLeft: 20,fontSize: 16}}>Select Payment Method :</Text>
      <View style={{flexDirection:'row'}}>
      <View style={{height: 60, width: '40%',borderRadius: 10,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'white'}}>
      <TouchableOpacity>
       <Text style={{alignSelf:'center',justifyContent:'center',color: "#527FF7",marginTop: 15,fontWeight:'bold'}}>ONLINE PAYMENT</Text> 
       </TouchableOpacity>  
      </View>
      <View style={{height: 60, width: '40%',borderRadius: 10,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'white',marginLeft: 30}}>
      <TouchableOpacity>
       <Text style={{alignSelf:'center',justifyContent:'center',color: "#527FF7",marginTop: 15,fontWeight:'bold'}}>CASH ON DELIVERY</Text> 
       </TouchableOpacity>  
      </View>
      </View>
      <Text style={{marginHorizontal: 20,marginVertical: 20}}>My billing and shipping address are the same</Text>
      <Text style={{fontWeight:'bold',marginVertical: 10,marginHorizontal: 30}}>Name</Text>
      <Text style={{marginVertical: 30,marginHorizontal:30}}>Address</Text>
      <View style={{flexDirection:'row'}}>
       <View style={{flex: 0.6,marginHorizontal: 20}}>
       <Text style={{marginVertical: 10,marginLeft: 40}}>Subtotal</Text>
       <Text style={{marginVertical: 10,marginLeft: 40}}>Shipping</Text>
       </View>
       <View style={{flex: 0.4}}>
        <Text style={{marginLeft: 30,marginVertical: 10}}>₹ 90.00</Text>
        <Text style={{marginLeft: 30,marginVertical: 10}}>₹ 40.00</Text>
       </View>
      </View>
      <View style={{borderColor:"#B8B7B6",borderWidth: 1,marginVertical: 20}}></View>
      <View style={{flexDirection:'row'}}>
      <View style={{flex: 0.6,marginHorizontal: 20}}>
       <Text style={{marginVertical: 10,marginLeft: 40,fontWeight:'bold'}}>Total</Text>
       </View>
       <View style={{flex: 0.4}}>
        <Text style={{marginLeft: 30,marginVertical: 10,fontWeight:'bold'}}>₹ 40.00</Text>
       </View>
      </View>
      </View>
      <View style={{flex:0.2}}>
      <View style={{flexDirection:'row'}}>
      <View style={{height: 50,width: '40%', borderRadius: 20,borderColor:"white",borderWidth: 1, marginTop: 10,marginLeft: 20,backgroundColor:"#67E3F9"}}>
       <TouchableOpacity>
      <Text style={{alignSelf:'center',justifyContent:'center',color:'white',marginTop: 10}}>Back</Text>
      </TouchableOpacity>
      </View>
      <View style={{height: 50,width: '40%', borderRadius: 20,borderColor:"white",borderWidth: 1, marginTop: 10,marginLeft: 40,backgroundColor:"#6FF99D"}}>
     <TouchableOpacity>
      <Text style={{alignSelf:'center',justifyContent:'center',color:'white',marginTop: 10}}>Confirm Order</Text>
      </TouchableOpacity>
      </View>
      </View>
      </View>
      </View>
    );
  }
}
export default payments;