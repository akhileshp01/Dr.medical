'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList} from 'react-native';


class doctordetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        {
          "image": "https://cdn4.iconfinder.com/data/icons/web-ui-color/128/Account-512.png",
          "name": "Dr. Akhil",
        },
      ],
    };
  }

  renderDoctorList = ({item, index}) =>{
    return(
      <View>
   <View style={{height:80,
   flexDirection:'row',
   padding:'3%',
   marginVertical: 10,
   marginHorizontal: 10,
   borderRadius: 10,
   backgroundColor: "white"}}>
       <View style={{height:50,
       width:'50%',
       //borderRadius:80,
       alignItems:'center',
       justifyContent:'center',
       //backgroundColor:'#D6183A'
      }}>
      <Text style={{}}>Dr.Akhil</Text>
       </View>
       <View style={{height:50,
           width:'60%',
           justifyContent:'center',
           marginLeft:'30%'}}> 
          <Image source={{uri: "https://cdn4.iconfinder.com/data/icons/web-ui-color/128/Account-512.png"}} style={{width: 60, height: 60}}/>
       </View>
   </View>
   </View> 
     )

 }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
        <View style={{flex: 0.1, backgroundColor:"white"}}>
          <Text style={{justifyContent:'center',alignSelf:'center',marginVertical: 30, fontSize: 18}}>Which doctor would you like to see</Text>
        </View> 
        <View style={{flex: 0.9}}>
        <FlatList                                      
                data={this.state.data}
                renderItem={({ item }) => this.renderDoctorList(item)}
            />
          </View>  
      </View>
    );
  }
}
export default doctordetails;