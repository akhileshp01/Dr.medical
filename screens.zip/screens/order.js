'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList, TouchableOpacity, TextInput} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ScrollView } from 'react-native-gesture-handler';

class order extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      couponcode:''
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View style={{flex: 0.15}}>
      <View style={{flexDirection:'row'}}>
     <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'cart'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'map-marker'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'currency-inr'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'#88B3E9'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'clipboard-text'} />
      </View>
      </TouchableOpacity>
      </View>
      </View>
      <View style={{flex: 0.7}}>
      <View style={{alignSelf:'center',justifyContent:'center',height: 90, width: 90,borderRadius: 50,borderWidth: 1,backgroundColor:"#0B1C48",marginTop: 60}}>
       <Icon
        style={{justifyContent: 'center',alignSelf: 'center',color: 'white',fontSize: 50,}}
        name={'check'} />
        </View>
        <View style={{height: '50%',width:'80%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',borderRadius: 10}}>
        <Text style={{color:"green",justifyContent: 'center',alignSelf: 'center',fontSize: 18,}}>Success</Text>
        <View style={{flexDirection:'row',marginTop: 20}}>
        <Text style={{justifyContent: 'center',alignSelf: 'center',marginLeft: 60}}>Transaction ID:</Text>
        <Text style={{color:"red",justifyContent: 'center',alignSelf: 'center'}}>145**********</Text>
        </View>
        <Text style={{justifyContent: 'center',alignSelf: 'center'}}>Check your email for a booking</Text>
        <Text style={{justifyContent: 'center',alignSelf: 'center'}}>confirmation. We'll see u soon!</Text>
        <View style={{flexDirection:'row',marginVertical: 20}}>
        <View style={{width:'40%',backgroundColor:"#0B1C48",borderRadius: 15,marginHorizontal: 20,height: '150%'}}>
        <TouchableOpacity>
        <Text style={{fontSize: 14,fontWeight:'bold',color:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 10}}>MORE</Text>
        </TouchableOpacity>
        </View>
        <View style={{width:'40%',backgroundColor:"#0B1C48",borderRadius: 15,height: '150%'}}>
        <TouchableOpacity>
        <Text style={{fontSize: 14,fontWeight:'bold',color:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 10}}>SHOP</Text>
        </TouchableOpacity>
        </View>
        </View>
        </View>
      </View>
      </View>
    );
  }
}
export default order;