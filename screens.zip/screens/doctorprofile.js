'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList} from 'react-native';
import MaterialCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';


class doctorprofile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
       <View style={{flex: 0.4}}>
         <View style={{height:140,width:'40%',borderRadius:120,alignSelf:'center',justifyContent:'center', backgroundColor:"white", marginVertical: 50}}>
         <Image source={{uri: "https://cyrefugeecouncil.org/wp-content/uploads/2018/01/users81.png"}} style={{width: 100, height: 120,justifyContent:'center',alignSelf:'center'}}/>
         </View>
         <Text style={{alignSelf:'center',justifyContent:'center', fontSize: 20}}>Dr.Alex M.D.Oncologist</Text>
       </View>
       <View style={{flex: 0.6}}>
       <View style={{flexDirection:'row'}}>
         <View style={{flex: 0.5,backgroundColor:"white",marginHorizontal: 5, height: 65}}>
           <Text style={{alignSelf:'center',justifyContent:'center',marginTop: 10}}>Available Days</Text>
           <Text style={{alignSelf:'center',justifyContent:'center',color:"#689CDF"}}>M/W/F</Text>
         </View>
         <View style={{flex: 0.5, backgroundColor:"white", marginHorizontal: 5}}>
           <Text style={{alignSelf:'center',justifyContent:'center',marginTop: 10}}>Fee</Text>
           <Text style={{alignSelf:'center',justifyContent:'center',color:"#689CDF"}}>600/Session</Text>
         </View>
       </View>
       <Text style={{alignSelf:'center',justifyContent:'center',color:"#689CDF",marginTop: 10,fontSize: 18}}>About Doctor</Text>
       <Text style={{alignSelf:'center',justifyContent:'center', marginTop: 10}}>Name: Dr.Alex M.D</Text>
       <Text style={{marginHorizontal: 10}}>Designation Sr. Consultant Medical Oncologist[M.B.B.S.(Honours); M.D & D.N.B(Diplomate of National Board]</Text>
       <Text style={{alignSelf:'center',justifyContent:'center'}}>Email info@amegahospitals.com</Text>
       <Text style={{alignSelf:'center',justifyContent:'center'}}>(+91)9160900058</Text>
       <View style={{backgroundColor: "#689CDF", borderRadius: 15, marginHorizontal: 15, marginVertical: 20, height: 50}}>
         <Text style={{alignSelf:'center',justifyContent:'center',color:"white",marginVertical: 10,fontSize: 18}}>Book An Appointment</Text>
       </View>
       </View>
      </View>
    );
  }
}
export default doctorprofile;