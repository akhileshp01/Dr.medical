'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList} from 'react-native';
import MaterialCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';


class doctorlist extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        {
          "image": "https://cdn4.iconfinder.com/data/icons/web-ui-color/128/Account-512.png",
          "name": "Dr. Akhil",
        },
      ],
    };
  }

  renderDoctorList = ({item, index}) =>{
    return(
      <View>
   <View style={{
   padding:'3%',
   marginVertical: 10,
   marginHorizontal: 10,
   borderRadius: 10,
   backgroundColor: "white"}}>
     <View style={{flexDirection:'row',}}>
       <View style={{height:50,
       width:'30%',
       //borderRadius:80,
       alignItems:'center',
       justifyContent:'center',
       //backgroundColor:'#D6183A'
      }}>
      <Image source={{uri: "https://cdn4.iconfinder.com/data/icons/web-ui-color/128/Account-512.png"}} style={{width: 60, height: 60}}/>
       </View>
       <View style={{height:50,
           width:'60%',
           justifyContent:'center',
           //marginLeft:'30%'
          }}> 
          <Text style={{}}>Dr.Akhil</Text>
          <Text>Oncologist</Text>
       </View>
       </View>
       <View style={{borderColor: "#E6E3E3",borderWidth: 1, marginVertical: 10}}></View>
       <View style={{flexDirection:'row'}}>
         <View style={{height: 40,width: 80,backgroundColor:"#4BBABB",borderRadius: 10,marginLeft: 10}}>
           <Text style={{alignSelf:'center',justifyContent:'center',color:"white",marginVertical: 10}}>Call Now</Text>
         </View>
         <View style={{height: 40,width:'50%',backgroundColor:"#4BBABB",borderRadius: 10,marginLeft: 60}}>
           <Text style={{alignSelf:'center',justifyContent:'center',color:"white",marginVertical: 10}}>BookAppointment</Text>
         </View>
       </View>
   </View>
   </View> 
     )

 }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
       <View style={{flex: 0.1,backgroundColor:"#4BBABB"}}>
         <Text style={{alignSelf:'center',justifyContent:'center',color: "white", fontSize: 18,fontWeight:'bold',marginVertical: 25}}>Select Doctors</Text>
       </View>
       <View style={{flex: 0.9}}>
        <FlatList                                      
          data={this.state.data}
          renderItem={({ item }) => this.renderDoctorList(item)}/>
          </View>
      </View>
    );
  }
}
export default doctorlist;