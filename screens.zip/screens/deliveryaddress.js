'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ScrollView } from 'react-native-gesture-handler';

class deliveryaddress extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      
    };
  }
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View style={{flex: 0.1}}>
      <View style={{flexDirection:'row'}}>
     <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'white'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'cart'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'white'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'map-marker'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'white'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'currency-inr'} />
      </View>
      </TouchableOpacity>
      <TouchableOpacity>
      <View style={{height: 60, width: 60,borderRadius: 50,borderWidth:1,backgroundColor:"white",marginTop: 20,marginHorizontal: 20,borderColor:'white'}}>
      <Icon
        style={{fontSize: 30,marginTop:10,marginLeft: 10,color:"#B8B7B6"}}
        name={'clipboard-text'} />
      </View>
      </TouchableOpacity>
      </View>
      </View>
      <View style={{flex: 0.9}}>
      <Text style={{marginHorizontal: 40,marginTop: 30}}>Shopping Address:</Text>
      <View style={{height: '20%',width: '85%',backgroundColor:"white",marginHorizontal: 30,marginVertical: 20,borderRadius: 20}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',marginVertical: 50,fontSize: 20,fontWeight:'500'}}>Full Address</Text>
      </View>
      <Text style={{marginHorizontal: 30,marginVertical: 10}}>Your delivery info:</Text>
      <View style={{height: '6%',width: '70%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 15,borderRadius: 20}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',color:"#B8B7B6"}}>First Name</Text>
      </View>
      <View style={{height: '6%',width: '70%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',borderRadius: 20,marginTop: 15}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',color:"#B8B7B6"}}>Last Name</Text>
      </View>
      <View style={{height: '6%',width: '70%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 15,borderRadius: 20}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',color:"#B8B7B6"}}>Company(OPtional)</Text>
      </View>
      <View style={{height: '6%',width: '70%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',borderRadius: 20,marginTop: 15}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',color:"#B8B7B6"}}>State</Text>
      </View>
      <View style={{height: '6%',width: '70%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 15,borderRadius: 20}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',color:"#B8B7B6"}}>District</Text>
      </View>
      <View style={{height: '6%',width: '70%',backgroundColor:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 15,borderRadius: 20}}>
      <Text style={{justifyContent: 'center',alignSelf: 'center',color:"#B8B7B6"}}>Pincode</Text>
      </View>
      <View style={{flexDirection:'row'}}>
      <View style={{flex: 0.5}}>
      <TouchableOpacity>
      <View style={{height: '35%',width: '70%',backgroundColor:"#87E1D2",marginTop: 15,borderRadius: 20,marginHorizontal: 10}}>
      <Text style={{color:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 10}}>Back</Text>
      </View>
      </TouchableOpacity>
      </View>
      <View style={{flex: 0.5}}>
      <TouchableOpacity>
      <View style={{height: '35%',width: '70%',backgroundColor:"#88D996",marginTop: 15,borderRadius: 20,marginHorizontal: 10}}>
      <Text style={{color:"white",justifyContent: 'center',alignSelf: 'center',marginTop: 10}}>Next Step</Text>
      </View>
      </TouchableOpacity>
      </View>
      </View>
      </View>
      </View>
    );
  }
}
export default deliveryaddress;