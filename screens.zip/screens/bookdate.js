'use strict';

import React, { Component } from 'react';
import { StyleSheet,View,Image,Text, FlatList, TouchableOpacity, TextInput, Button} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import DateTimePicker from '@react-native-community/datetimepicker';

class bookdate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        newdate: '',
        date: ''
    };
  }

   onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    //setShow(Platform.OS === 'ios');
    setDate(currentDate);
  };

   showMode = currentMode => {
    setShow(true);
    setMode(currentMode);
  };

   showDatepicker = () => {
    showMode('date');
  };

   showTimepicker = () => {
    showMode('time');
  };
 
  render() {
    return (
      <View style={{flex: 1, backgroundColor:"#E9E8E8"}}>
      <View>
        <Button onPress={this.showDatepicker} title="Date" />
      </View>
      <View>
        <Button onPress={this.showTimepicker} title="Time" />
      </View>
      {show && (
        <DateTimePicker
          testID="dateTimePicker"
          value={this.state.date}
          mode={mode}
          is24Hour={true}
          display="default"
          onChange={onChange}
        />
      )}
    </View>
    );
  }
}
export default bookdate;